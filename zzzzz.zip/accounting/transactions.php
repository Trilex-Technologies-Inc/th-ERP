<?php
	include('include.php');

	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);

	$narrative = getParam('narrative');
	$sql = "
	select
	    transactionid,
	    unix_timestamp(transtime) as transtime,
		narrative
	from transaction
	where narrative like '$narrative%'
	and transtime between from_unixtime($starttime) and from_unixtime($endtime)
	and valid = 1
	order by transactionid desc
	";
    $rs = query($sql);


?>

<head>
<title>thERP - <?php etr("Transactions") ?></title>
<?php
styleSheet();
?>
</head>

<body>

<?php menubar("transactions.php") ?>
<?php title(tr("Transactions")) ?>
<form action="transactions.php" method="GET">
<div class="card border-0 shadow-sm mb-3"><div class="card-body">
<div class="container-fluid px-0 erp-form-layout">
<div class="row g-3 align-items-center mb-2"><div class="col-12 col-md-auto"><?php etr("Narrative") ?>:</div><div class="col-12 col-md-auto"><?php textbox("narrative", $narrative) ?></div>
</div><div class="row g-3 align-items-center mb-2">
	<div class="col-12 col-md-auto"><?php etr("Interval") ?>:</div>
	<div class="col-12 col-md-auto"><?php datebox("starttime", formatDate($starttime)) ?></div>
	<div class="col-12 col-md-auto"><?php datebox("endtime", formatDate($endtime)) ?></div>
</div>
<div class="row g-3 align-items-center mb-2">
<div class="col-12 col-md-auto"><input type="submit" name="search" value="<?php etr("Search") ?>" /></div>
</div>

</div></div></div>
</form>
<form action="transactions.php" method=POST>
<div class="card border-0 shadow-sm mb-3">
<div class="card-header bg-body-tertiary"><div class="row fw-semibold"><div class="col-2"><?php etr("Id") ?></div><div class="col-7"><?php etr("Narrative") ?></div><div class="col-3"><?php etr("Date") ?></div></div></div>
<div class="list-group list-group-flush">
<?php
    $i = 0;
    while ($row = fetch_object($rs)) {
        echo "<div class='list-group-item'><div class='row align-items-center'><div class='col-2'><a href='transaction.php?transactionid=$row->transactionid'>$row->transactionid</a></div>";
        echo "<div class='col-7'><a href='transaction.php?transactionid=$row->transactionid'>$row->narrative</a></div>";
        echo "<div class='col-3'>" . date(DATE_PATTERN, $row->transtime) . "</div></div></div>";
        $i++;
    }
?>
</div></div>
<br/>
<?php
newButton("register_transaction.php");
echo "&nbsp;&nbsp;";
$params = "starttime=$starttime&endtime=$endtime&narrative=$narrative";
button("Print", "print", "trans_report.php?$params");
?>
</form>
<?php bottom() ?>
</body>
