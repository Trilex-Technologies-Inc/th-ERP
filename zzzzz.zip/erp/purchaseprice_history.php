<?php
include('include.php');
$productid = getParam('productid');
$productidSql = sql_string($productid);

$sql = "
select
  po.orderid,
  unitprice,
  quantity,
  unix_timestamp(orderdate) as orderdate
from purchaseorder_item pi
join purchaseorder po on po.orderid=pi.orderid
where productid=$productidSql
";

$rs = query($sql);

$model = findValue("select model from product where productid=$productidSql");
?>

<head>
<?php metatag() ?>
<title>thERP - <?php etr("Purchase price history") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('purchase.php') ?>
<?php
title("Product > <a href='product.php?productid=$productid'>$model</a> > Purchase price history");
?>
<br/>
<div class="border">

<div class="card border-0 shadow-sm overflow-hidden"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
<th><?php etr("Date") ?></th>
<th><?php etr("Purchase order") ?></th>
<th><?php etr("Price") ?></th>
<th><?php etr("Quantity") ?></th>
<?php
    $class = "odd";
    while ($row = fetch_object($rs)) {
        echo "<tr class='$class'>";
        echo "<td>" . formatDate($row->orderdate) . "</td>";
        echo "<td><a href='purchaseorder.php?orderid=$row->orderid'>$row->orderid</a></td>";
        echo "<td align=right>";
        echo formatMoney($row->unitprice);
        echo "</td>";
        echo "<td align=right>$row->quantity</td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table></div></div>
<?php bottom() ?>
</body>
